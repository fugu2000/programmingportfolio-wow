class Laser {
  // Member Variables
  int  y, w, h, speed;
  float x;

  PImage laser;

  // Constructor
  Laser(float x, int y) {
    this.x = x;
    this.y = y;
    w = 5;
    h = 10;
    speed = 10;
    laser = loadImage("Laser.png");
  }

  // Member Methods
  void display() {
    imageMode(CENTER);
    image(laser, x, y);
  }

  void move() {

      y -= speed;
    }
  

  boolean reachedTop() {
    if (y < 0 - (h / 2)) {
      return true;
    } else {
      return false;
    }
  }
  boolean intersect(Rock r) {
    float d = dist(x, y, r.x, r.y);
    if (d < r.diam) {
      return true;
    } else {
      return false;
    }
  }
}
