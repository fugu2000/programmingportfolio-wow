class Powerup {
  // Member Variables
  int x, y, diam, speed;
  char type;
  PImage powerup;

  // Constructor
  Powerup() {
    x = int(random(width));
    y = -25;
    diam = 20;
    speed = int(random(1, 5));
    powerup = loadImage("Star.png");
    int rand = int(random(4));
    if (rand == 0) {
      type = 'h';
    } else if (rand == 1) {
      type = 'a';
    } else if (rand == 2) {
      type = 't';
    } else {
      type = 's';
    }
  }

  // Member Methods
  void display() {
    imageMode(CENTER);
    image(powerup, x, y);
  }


  void move() {
    y += speed;
  }

  boolean reachedBottom() {
    if (y > height + (diam / 2)) {
      return true;
    } else {
      return false;
    }
  }
  boolean intersect(Spaceship s) {
    float d = dist(x, y, s.x, s.y);
    if (d < 50) {
      return true;
    } else {
      return false;
    }
  }
}
