class Star {
  // Member Variables
  int x, y, diam, speed;


  // Constructor
  Star() {
    x = int(random(width));
    y = -10;
    diam = int(random(1, 4));
    speed = int(random(1, 5));
  }

  // Member Methods
  void display() {
    fill(160);
    ellipse(x, y, diam, diam);
  }

  void move() {
    y += speed;
  }

  boolean reachedBottom() {
    if (y > height + (diam / 2)) {
      return true;
    } else {
      return false;
    }
  }
}
