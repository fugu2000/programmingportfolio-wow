class Spaceship {
  // Member Variables
  int x, y, w,  turretCount, health, lasX;

  PImage ship;

  // Constructor
  Spaceship() {
    x = width / 2;
    y = height / 2;
    w = 100;
    turretCount = 1;
    health = 3;
    ship = loadImage("New Piskel-1.gif");
  }

  // Member Methods
  void display() {
    imageMode(CENTER);
    image(ship, x, y);
  }

  void move(int tempX, int tempY) {
    x = tempX;
    y = tempY;
    lasX = tempX - (65 / 2);
  }

  boolean fire() {
    if (score > 0) {
      return true;
    } else {
      return false;
    }
  }
  boolean intersect(Rock r) {
    float d = dist(x, y, r.x, r.y);
    if (d < 50) {
      return true;
    } else {
      return false;
    }
  }
}
