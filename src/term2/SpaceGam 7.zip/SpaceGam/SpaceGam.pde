// Marcus Nishikawa | Nov 6 2024 | SpaceGame

import processing.sound.*;
SoundFile laser, explosion;

Spaceship s1;
ArrayList<Rock> rocks = new ArrayList<Rock>();
ArrayList<Laser> lasers = new ArrayList<Laser>();
ArrayList<Powerup> powerups = new ArrayList<Powerup>();
ArrayList<Star> stars = new ArrayList<Star>();

PFont dos;

String fadingText;

int score, level, rockRate, intensity, tX, tY, floatY;

float laserDist;

Timer rTime, lTime, puTime;

boolean play, gameOver, textFade;

void setup() {
  size(800, 800);
  s1 = new Spaceship();
  score = 10;
  level = 1;
  play = false;
  rTime = new Timer(500 - (rockRate * 25));
  rTime.start();
  lTime = new Timer(50);
  puTime= new Timer(5000);
  puTime.start();
  dos = createFont("PerfectDOSVGA437.ttf", 35);
  laser = new SoundFile(this, "retro-laser-1-236669.mp3");
  explosion = new SoundFile(this, "8-bit-explosion_F.wav");
}

void draw() {
  if (!play) {
    startScreen();
  } else {
    noCursor();
    background(20);

    if (score >= (500 * level)) {
      level ++;
      rockRate = level;
    }
    stars.add(new Star());
    for (int i = 0; i < stars.size(); i++) {
      Star s = stars.get(i);
      s.display();
      s.move();
    }
    for (int i = 0; i < powerups.size(); i++) {
      Powerup pu = powerups.get(i);
      if (pu.intersect(s1)) {
        if (pu.type == 'h') {
          s1.health ++;
          fadingText("Repair Package Received!");
        } else if (pu.type == 't' && s1.turretCount <= 4) {
          s1.turretCount ++;
          fadingText("Turret Package Received!");
        } else {
          score += 200;
          fadingText("Care Package Received!");
        }
        powerups.remove(pu);
      }
      pu.display();
      pu.move();
      if (pu.reachedBottom()) {
        powerups.remove(pu);
      }
    }


    if (rTime.isFinished()) {
      rocks.add(new Rock());
      rTime.totalTime = (500 - (rockRate * 25));
      rTime.start();
    }
    if (puTime.isFinished()) {
      powerups.add(new Powerup());
      puTime.start();
    }
    for (int i = 0; i < rocks.size(); i++) {
      Rock rock = rocks.get(i);
      rock.display();
      rock.move();
      if (rock.reachedBottom()) {
        rocks.remove(rock);
      }
      if (s1.intersect(rock)) {
        rocks.remove(rock);
        s1.health --;
        fadingText("Hull Breach Detected!");            
        explosion.play();
      }
    }
    for (int i = 0; i < lasers.size(); i++) {
      Laser laser = lasers.get(i);
      for (int j = 0; j < rocks.size(); j++) {
        Rock rock = rocks.get(j);
        if (laser.intersect(rock)) {
          rock.diam -= 10;
          if (rock.diam < 10) {
            rocks.remove(rock);
          }
          lasers.remove(laser);
          score += 5;
        }
      }
      laser.display();
      laser.move();
      if (laser.reachedTop()) {
        lasers.remove(laser);
      }
    }
    s1.display();
    s1.move(mouseX, mouseY);
    infoPanel();

    if (textFade) {
      textSize(20);
      fill(255, intensity);
      text(fadingText, tX, tY + floatY);
      intensity -= 2;
      floatY--;
      if (intensity < 1) {
        textFade = false;
      }
    }
    if (s1.health < 1) {
      gameOver();
      play = false;
      noLoop();
      gameOver = true;
    }
  }
}
void keyPressed() {
  if (key == ' ') {
    fire();
    if (!play && !gameOver) {
      play = true;
    }
  }
}
void infoPanel() {
  rectMode(CENTER);
  fill(127, 127);
  rect(100, 20, 500, 40);
  rect(750, 20, 210, 40);
  fill(255);
  textFont(dos);
  textSize(35);
  text("Wage Earned:$" + score, 15, 30);
  text("Health:" + s1.health, 15, height - 30);
  text("Level:" + level, 655, 33);
}

void startScreen() {
  background(0);
  fill(255);
  textMode(CENTER);
  textSize(30);
  textFont(dos);
  text("Here for the Job?", width / 3, 300);
  text("Space to Clock In", width / 3, 500);
}

void gameOver() {
  background(0);
  fill(255);
  textSize(20);
  text("EXPULSION NOTICE", 300, 300);
  text("REASON FOR EXPULSION: WASTE OF COMPANY FUNDS", 100, 500);
  text("SEVERANCE PAYMENT: $" + score, 300, 700);
}

void ticker() {
}

void mousePressed() {
  fire();
}

void fire() {
  if (s1.fire() && lTime.isFinished() && play == true) {
    for (int l = 0; l < int(s1.turretCount); l++) {
      if (score > 0) {
        laserDist = 65 / (s1.turretCount + 1);

        lasers.add(new Laser(s1.lasX + (laserDist * (l + 1)), s1.y));
        lTime.start();
      }
    }
    score --;
    laser.play();
  }
}

void fadingText(String text) {
  textFade = true;
  tX = s1.x;
  tY = s1.y;
  floatY = 0;
  intensity = 100;
  fadingText = text;
}
