class Rock {
  // Member Variables
  int x, y, diam, speed;

  PImage rock;

  // Constructor
  Rock() {
    x = int(random(width));
    y = -25;
    diam = int(random(20 + level * 5, 50 + (level * 5)));
    speed = int(random(1 + level, 5 + level));
    rock = loadImage("Rock.png");
  }

  // Member Methods
  void display() {
    imageMode(CENTER);
    if (diam > 0) {
      rock.resize(diam, diam);
      image(rock, x, y);
    }
  }

  void move() {
    y += speed;
  }

  boolean reachedBottom() {
    if (y > height + (diam / 2)) {
      return true;
    } else {
      return false;
    }
  }
}
